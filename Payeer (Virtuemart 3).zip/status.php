<?php
$_REQUEST['option']='com_virtuemart';
$_REQUEST['view']='pluginresponse';
$_REQUEST['task']='pluginnotification';
$_REQUEST['tmpl']='component';
$_REQUEST['format'] = 'raw';
$_REQUEST['pelement'] = 'payeer';
include('../../../index.php');
